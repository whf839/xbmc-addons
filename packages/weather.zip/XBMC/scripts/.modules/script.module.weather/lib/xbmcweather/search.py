## Utility to search weather.com for town codes

import os
import xbmcgui
import xbmc
import urllib2
import re


class TownSearch:
    """
        Searches for a town from weather.com and
        sets the weather.com town code in settings.
    """
    # weather.com partner id
    PARTNER_ID = "1004124588"
    # weather.com partner key
    PARTNER_KEY = "079f24145f208494"
    # base urls
    BASE_URLS = [
        "http://xoap.weather.com/search/search?where=%s",
        "http://xoap.weather.com/weather/local/%s?cc=*&unit=e&dayf=5&prod=xoap&link=xoap&par=%s&key=%s"
    ]

    def __init__( self, addon, index ):
        # set Addon
        self.Addon = addon
        # index number of setting
        self.index = index

    def get_town( self ):
        try:
            # get search text
            text = self._get_search_text( heading=self.Addon.getLocalizedString( 30731 ) )
            # skip if user cancels keyboard
            if ( text is not None ):
                # fetch source
                xml = self._fetch_source( text )
                # proceed if successful
                if ( xml is not None ):
                    # select town
                    town = self._select_town( xml, text.upper() )
                    # only set if user selected a town
                    if ( town is not None ):
                        # set settings
                        self.Addon.setSetting( "town%s" % ( self.index, ), town[ 0 ] )
                        self.Addon.setSetting( "id%s" % ( self.index, ), town[ 1 ] )
        except Exception, e:
            # inform user
            ok = xbmcgui.Dialog().ok( self.Addon.getAddonInfo( "Name" ), self.Addon.getLocalizedString( 30732 ) )
        # open settings
        self.Addon.openSettings()

    def _get_search_text( self, default="", heading="", hidden=False ):
        """ shows a keyboard and returns a value """
        # show keyboard for input
        keyboard = xbmc.Keyboard( default, heading, hidden )
        keyboard.doModal()
        # return user input unless canceled
        if ( keyboard.isConfirmed() and keyboard.getText() != "" ):
            return keyboard.getText()
        # user cancelled or entered blank
        return None

    def _fetch_source( self, text ):
        # check for a valid weather.com code and set appropriate url
        if ( len( text ) == 8 and text[ : 4 ].isalpha() and text[ 4 : ].isdigit() ):
            # valid id's are uppercase
            url = self.BASE_URLS[ 1 ] % ( text.upper(), self.PARTNER_ID, self.PARTNER_KEY, )
        else:
            # search FIXME: does this need to be urlencoded?
            url = self.BASE_URLS[ 0 ] % ( text.replace( " ", "+" ), )
        # add headers
        headers = {
            "User-Agent": "XBMC/%s" % ( xbmc.getInfoLabel( "System.BuildVersion" ), ),
            "Accept": "application/xml; charset=UTF-8"
        }
        # request base url
        request = urllib2.Request( url, headers=headers )
        # open requested url and fetch source
        xml = urllib2.urlopen( request ).read()
        # return results
        return xml

    def _select_town( self, xml, text ):
        # parse for a town name if valid weather.com id was entered
        if ( len( text ) == 8 and text[ : 4 ].isalpha() and text[ 4 : ].isdigit() ):
            # parse town name and add id
            town = [ re.search( "<dnam>([^<]+)</dnam>", xml ).group( 1 ), text ]
            # valid weather source, may as well cache it
            base_path = os.path.join( self.Addon.getAddonInfo( "Profile" ), "source", "weather-%s.xml" % ( text, ) )
            # create path to cache
            if ( not os.path.isdir( os.path.dirname( base_path ) ) ):
                os.makedirs( os.path.dirname( base_path ) )
            # save source
            open( base_path, "w" ).write( xml )
        else:
            # parse town list
            towns = dict( [ [ unicode( town, "UTF-8" ), [ unicode( town, "UTF-8" ), id, type ] ] for id, type, town in re.findall( "<loc.+?id=\"([^\"]+)\".+?type=\"([^\"]+)\">([^<]+)</loc>", xml ) ] )
            # inform user if no list found
            if ( not towns ):
                return None
            # set titles for select dialog
            titles = towns.keys()
            # if only one result return it
            if ( len( titles ) == 1 ):
                choice = 0
            else:
                # initialize to None in case no selection
                town = None
                # sort titles (dict() scrambles them)
                titles.sort()
                # get user selection
                choice = xbmcgui.Dialog().select( self.Addon.getLocalizedString( 30730 ), titles )
            # return selection
            if ( choice >= 0 ):
                town = towns[ titles[ choice ] ]
        # return result
        return town
