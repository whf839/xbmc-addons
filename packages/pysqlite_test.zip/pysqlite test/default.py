from pysqlite2 import dbapi2 as sqlite
print "import ok"

db = sqlite.connect( "q:\\test.db" )
print "open ok"
db.close()
print "close ok"
