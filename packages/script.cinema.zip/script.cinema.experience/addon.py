###########################################################
"""
    Cinema Experience:
    - creates a movie theater experience in the privacy of your home
    
    - plays # of optional Movie Theater intro videos
    - plays optional slideshow w/ optional music, intro/outro videos/still images
    - plays # of optional random trailers w/ optional intro/outro videos
    - plays highlighted video w/ optional intro/outro videos, rating video and dolby/dts video
    - plays # optional Movie Theater outro videos
"""
############################################################
import sys




if ( __name__ == "__main__" ):
    # create experience
    from resources.lib.experience import *
    # create the experience
    playlist = Experience()._create_experience()
    if ( isinstance( playlist, list ) ):
        for item in playlist:
            print item
    else:
        # an error occurred
        print playlist

