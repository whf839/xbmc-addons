## Weather.com (standard)

import sys
import xbmcaddon

# Addon class
Addon = xbmcaddon.Addon( id="script.weather.standard" )


if ( __name__ == "__main__" ):
    # is this a request from user to log properties
    if ( sys.argv[ 1 ] == "properties" ):
        # get property printer module
        from xbmcweather import pprinter
        # print properties
        pprinter.PPrinter( addon=Addon ).print_properties()
    # is this a request from user to select new town
    elif sys.argv[ 1 ].startswith( "search" ):
        # get search module
        from xbmcweather import search
        # search for town
        search.TownSearch( addon=Addon, index=sys.argv[ 1 ].replace( "search", "" ) ).get_town()
    # standard weather fetcher
    else:
        # get standard weather module
        from xbmcweather import weather, localize
        # get localize functions
        l = localize.Localize()
        # fetch weather
        weather.Weather( addon=Addon, index=sys.argv[ 1 ], refresh=sys.argv[ 2 ] == "1", localize=( l.localize_unit, l.localize_text, l.localize_text_special, ) ).fetch_weather()
