## Player module: main module

import os
import xbmc
from threading import Timer


class XBMCPlayer( xbmc.Player ):
    """ 
        Subclass of XBMC Player class.
        Overrides onplayback events, for custom actions.
    """

    def __init__( self, *args, **kwargs ):
        # init Player class
        xbmc.Player.__init__( self )
        # set our Addon class
        self.Addon = kwargs[ "Addon" ]
        # log started action
        self._log_addon_action( "started" )
        # get the current volume, infolabel returns '-12.0 dB' format
        self.current_volume = int( ( 1 - abs( float( xbmc.getInfoLabel( "Player.Volume" ).split( " " )[ 0 ] ) ) / 60 ) * 100 )
        # initialize timer
        self.fetch_timer = None
        # start
        self.startup()

    def _log_addon_action( self, action ):
        # log addon info
        xbmc.log( "=" * 80, xbmc.LOGNOTICE )
        xbmc.log( "[ADD-ON] - %s %s!" % ( self.Addon.getAddonInfo( "Name" ), action ), xbmc.LOGNOTICE )
        xbmc.log( "           Id: %s - Type: %s - Version: %s" % ( self.Addon.getAddonInfo( "Id" ), self.Addon.getAddonInfo( "Type" ), self.Addon.getAddonInfo( "Version" ) ), xbmc.LOGNOTICE )
        xbmc.log( "=" * 80, xbmc.LOGNOTICE )

    def startup( self ):
        # initialize current path
        self.current_path = ""
        # loop
        while True:
            # if user leaves library exit script
            if ( not xbmc.getCondVisibility( "Window.IsVisible(VideoLibrary)" ) ): break
            # get current path
            new_path = xbmc.getInfoLabel( "ListItem.Path" )
            # is a new item selected
            if ( new_path != self.current_path ):
                # cancel any timer
                self._cancel_timer()
                # set new timer FIXME: is 500 msec good
                self.fetch_timer = Timer( 0.5, self._play_tune, ( not ( new_path.startswith( self.current_path ) or self.current_path.startswith( new_path ) ), ) )
                # set new path
                self.current_path = new_path
                # start timer
                self.fetch_timer.start()
            # sleep FIXME: is 100 msec good
            xbmc.sleep( 100 )
        # exit script
        self._exit_script()

    def _cancel_timer( self ):
        # if there's a timer cancel it
        if ( self.fetch_timer is not None ):
            self.fetch_timer.cancel()

    def _play_tune( self, new_show=True ):
        # FIXME: only handles new shows, means no season level theme
        if ( new_show ):
            # set path to theme.mp3
            _path = xbmc.validatePath( os.path.join( self.current_path, "theme.mp3" ) )
            # fade-out volume
            self._fade_volume( volume=self.current_volume )
            # play file if it exists
            if ( os.path.isfile( _path ) ):
                self.play( _path )
            # stop playing file
            else:
                self.stop()
            # fade-in volume
            self._fade_volume( out=False, volume=self.current_volume )

    def _fade_volume( self, out=True, volume=0 ):
        # set initial start/end values
        volumes = range( 1, volume + 1 )
        # if fading out reverse order
        if ( out ):
            volumes.reverse()
        # calc sleep time, 1 second for fade time; only need to sleep if actually playing
        sleep_time = [ 0, int( float( 1000 ) / len( volumes ) ) ][ self.isPlaying() ] 
        # loop thru and set volume
        for volume in volumes:
            xbmc.executebuiltin( "XBMC.SetVolume(%d)" % ( volume, ) )
            # sleep
            xbmc.sleep( sleep_time )

    def _exit_script( self ):
        # cancel any timer
        self._cancel_timer()
        # stop tunes
        if ( self.isPlayingAudio() ):
            self._fade_volume( volume=self.current_volume )
            self.stop()
        # set volume to normal
        self._fade_volume( out=False, volume=self.current_volume )
        # log ended action
        self._log_addon_action( "ended" )
