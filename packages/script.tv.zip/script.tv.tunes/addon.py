## TV  Show Tunes

import sys
import xbmcaddon

# Addon class
Addon = xbmcaddon.Addon( "script.tv.tunes" )


if ( __name__ == "__main__" ):
    # player
    if ( len( sys.argv ) == 2 ):
        import resources.lib.player as player
        player.XBMCPlayer( xbmc.PLAYER_CORE_PAPLAYER, Addon=Addon )
